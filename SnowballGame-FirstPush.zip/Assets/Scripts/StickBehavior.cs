using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StickBehavior : MonoBehaviour
{
    // P R O P E R T I E S

    // break time
    float burnTime = 30; // in seconds
    // stick state
    public bool IsOnFire = false;

    // M E T H O D S
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void StickDestruction()
    {
        //Destroy(this.gameObject);
    }
}
